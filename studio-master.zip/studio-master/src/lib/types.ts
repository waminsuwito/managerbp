




import type { LucideIcon } from 'lucide-react';

export interface Material {
  id: string;
  name: string;
  quantity: number;
  capacity: number;
  unit: string;
  Icon: LucideIcon;
  lowLevelThreshold: number;
}

export interface Formula {
  id: string;
  name: string;
  materials: {
    materialId: string;
    quantity: number;
  }[];
  mixingTime: number; // in seconds
}

export const userRoles = [
  "super_admin",
  "admin_lokasi",
  "operator",
  "logistik_spareparts",
  "mekanik",
  "supervisor",
  "laborat",
  "tukang_las",
  "logistik_material",
  "hse_hrd_lokasi",
  "karyawan",
  "screen_view",
] as const;

export type UserRole = (typeof userRoles)[number];

export const jabatanOptions = [
  "ADMIN BP",
  "ADMIN LOGISTIK",
  "ADMIN PRECAST",
  "ADMIN QC",
  "HELPER",
  "HELPER BP",
  "HELPER CP",
  "HELPER LABORAT",
  "HELPER LAS",
  "HELPER PRECAST",
  "HELPER TAMBAL BAN",
  "HRD",
  "HSE/K3",
  "KEP KOOR BP",
  "KEP KOOR QC",
  "KEP KOOR TEKNIK",
  "KEPALA BP",
  "KEPALA GUDANG",
  "KEPALA MEKANIK",
  "KEPALA OPRATOR",
  "KEPALA PRECAST",
  "KEPALA SOPIR",
  "KEPALA WORKSHOP",
  "LAYAR MONITOR",
  "OPRATOR BATA RINGAN",
  "OPRATOR BP",
  "OPRATOR CP",
  "OPRATOR LOADER",
  "OPRATOR PAVING",
  "QC",
  "SOPIR DT",
  "SOPIR TM",
  "TUKANG BOBOK",
  "TUKANG LAS",
] as const;

export type UserJabatan = (typeof jabatanOptions)[number];

export const userLocations = [
  "BP PEKANBARU",
  "BP DUMAI",
  "BP BAUNG",
  "BP IKN",
] as const;

export type UserLocation = (typeof userLocations)[number];

export interface User {
  id: string;
  username: string;
  password?: string;
  role: UserRole;
  location?: UserLocation;
  nik?: string;
  jabatan?: UserJabatan;
}

export interface JobMixFormula {
  id: string;
  mutuBeton: string;
  pasir1: number;
  pasir2: number;
  batu1: number;
  batu2: number;
  air: number;
  semen: number;
}

export interface Schedule {
  id: string;
  customerName: string;
  projectLocation: string;
  concreteQuality: string;
  slump: string;
  volume: string;
  mediaCor: 'CP' | 'Manual';
  date: string; // YYYY-MM-DD format
}

export type BongkarStatus = 'Belum Dimulai' | 'Proses' | 'Istirahat' | 'Selesai';

export interface BongkarMaterial {
  id: string;
  namaMaterial: string;
  kapalKendaraan: string;
  namaKaptenSopir: string;
  volume: string;
  keterangan: string;
  waktuMulai: string | null;
  waktuSelesai: string | null;
  status: BongkarStatus;
  waktuMulaiIstirahat: string | null;
  totalIstirahatMs: number;
}

export interface AttendanceLocation {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
}

export interface GlobalAttendanceRecord {
  nik: string;
  nama: string;
  location: UserLocation;
  date: string; // YYYY-MM-DD
  absenMasuk: string | null; // ISO String
  terlambat: string | null; // e.g., "15m" or null
  absenPulang: string | null; // ISO String
  lembur: string | null; // e.g., "1h 30m" or null
  photoMasuk: string | null; // Data URI
  photoPulang: string | null; // Data URI
}

export interface AnonymousReport {
  id: string;
  reportText: string;
  photoDataUri: string | null;
  timestamp: string; // ISO String
  status: 'new' | 'read';
}

export interface AccidentReport {
  id: string;
  reporterId: string;
  reporterName: string;
  reporterNik: string;
  location: UserLocation;
  accidentLocation: string; // e.g., "Area Mixer", "Gudang Semen"
  accidentTimestamp: string; // ISO String
  description: string;
  photoDataUri: string | null;
  timestamp: string; // Submission timestamp
  status: 'new' | 'reviewed';
}

export interface DailyActivity {
  text: string | null;
  photo: string | null; // Data URI
  timestamp: string | null; // ISO String
}

export interface DailyActivityReport {
  userId: string;
  nik: string;
  username: string;
  location: UserLocation;
  date: string; // YYYY-MM-DD
  pagi: DailyActivity;
  siang: DailyActivity;
  lembur?: DailyActivity;
}

export interface BroadcastMessage {
  id: string;
  messageText: string;
  timestamp: string; // ISO String
}

interface UserFeedback {
    id: string;
    reporterId: string;
    reporterName: string;
    reporterNik: string;
    location: UserLocation;
    text: string;
    timestamp: string; // ISO String
    status: 'new' | 'read';
}

export type Suggestion = UserFeedback;
export type Complaint = UserFeedback;

export type ChecklistStatus = 'baik' | 'rusak' | 'perlu_perhatian';

export interface TruckChecklistItem {
  id: string;
  label: string;
  status: ChecklistStatus | null;
  photo: string | null; // Data URI
  notes?: string;
}

export interface TruckChecklistReport {
  id: string; // Composite key like `userId-YYYY-MM-DD`
  userId: string;
  userNik: string;
  username: string;
  location: UserLocation;
  timestamp: string; // ISO String of submission time
  items: TruckChecklistItem[];
}
