// This component is no longer used. Advanced settings are handled in the dashboard.
'use client';
export function MixingProcessForm() {
  return null;
}
