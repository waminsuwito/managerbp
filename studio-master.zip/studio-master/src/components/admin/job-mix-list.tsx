// This component is no longer used. Formula management is now handled in the dashboard.
'use client';
export function JobMixList() {
  return null;
}
