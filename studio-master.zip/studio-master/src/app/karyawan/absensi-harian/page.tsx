
'use client';

import { AttendanceForm } from '@/components/karyawan/attendance-form';

export default function AbsensiHarianKaryawanPage() {
    return <AttendanceForm />;
}
