import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-mix-adjustments.ts';